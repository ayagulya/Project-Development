// Random number of dice
number = Math.floor(Math.random() * 6 + 1);
document.getElementById('player1').innerHTML += '*';
document.getElementById('dice').src = "dice-"+number+'.png';
active = 1; // Active player
counter = 0; // How many user made moves
top_1 = 0; // Top score player 1
top_2 = 0; // Top score player 2
score = 0; // Current score of players

// Function to change Player
function switchPlayer(){
    if(active == 1){
        document.getElementById('player1').innerHTML = 'Player 1';
        active = 2;
        document.getElementById('player2').innerHTML += '*';
        if(score != 0){
            top_1 += score
            document.getElementById('top_1').innerHTML = top_1;
            document.getElementById('score_1').innerHTML = 0;
            score = 0
        }
        counter = 0;
    }else if(active == 2){
        document.getElementById('player2').innerHTML = 'Player 2';
        active = 1;
        document.getElementById('player1').innerHTML += '*';
        if(score != 0){
            top_2 += score
            document.getElementById('top_2').innerHTML = top_2;
            document.getElementById('score_2').innerHTML = 0;
            score = 0
        }
        counter = 0;
    }
}

// Function to roll Dice
function rollDice(){
    counter++;
    number = Math.floor(Math.random() * 6 + 1);
    score += number;
    checker = parseInt(document.getElementById('top_'+active).innerHTML);
    if(checker + score >= 100){
        document.getElementById('winner').innerHTML = 'CONGRATULATION PLAYER ' + active + '. YOU WON!'
        document.getElementById('winner').style.display = 'block'
        checker += score
        document.getElementById('top_'+active).innerHTML = checker
        document.getElementById('roll').disabled = true;
        document.getElementById('hold').disabled = true;
    }
    document.getElementById('dice').src = "dice-"+number+'.png';
    document.getElementById('score_'+active).innerHTML = score;
    if(counter == 5){
        switchPlayer();
    }
}

// Function to start game again
function restart(){
    document.getElementById('roll').disabled = false;
    document.getElementById('hold').disabled = false;
    counter = 0;
    top_1 = 0;
    top_2 = 0;
    score = 0;
    document.getElementById('winner').style.display = 'none'
    document.getElementById('top_1').innerHTML = 0;
    document.getElementById('top_2').innerHTML = 0;
    document.getElementById('score_1').innerHTML = 0;
    document.getElementById('score_2').innerHTML = 0;
}
